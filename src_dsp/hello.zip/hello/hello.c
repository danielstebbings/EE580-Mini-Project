/*
 *  Copyright 2010 by Texas Instruments Incorporated.
 *  All rights reserved. Property of Texas Instruments Incorporated.
 *  Restricted rights to use, duplicate or disclose this code are
 *  granted through contract.
 *
 */
/***************************************************************************/
/*                                                                         */
/*     H E L L O . C                                                       */
/*                                                                         */
/*     Basic LOG event operation from main.                                */
/*                                                                         */
/***************************************************************************/

#include "hellocfg.h" //BIOS include file
#include "framework.h"

int16_t volatile mask = 0xffff;

//---------------------------------------------------------
//---------------------------------------------------------
void main(void)
{
    initAll();
    LOG_printf(&trace, "hello world!");
    return; // return to BIOS scheduler
}
//---------------------------------------------------------
//---------------------------------------------------------
void audioHWI(void)
{
    int16_t s16;
    s16 = read_audio_sample();

    if (MCASP->RSLOT)
    {
        // THIS IS THE LEFT CHANNEL!!!
        //s16 = process(s16);
        s16 &= mask;
    }
    else
    {
        // THIS IS THE RIGHT CHANNEL!!!
        //s16 = process(s16);
        s16 &= mask;
    }
    write_audio_sample(s16);
}

void dipPRD0(void)
{
    uint8_t dip_status8;
    DIP_get(DIP_8, &dip_status8);
    if(dip_status8)
    {
        LED_toggle(LED_1);
        LED_toggle(LED_2);
    }
}
void dipPRD1(void)
{
    uint8_t dip_status8;
    DIP_get(DIP_8, &dip_status8);
    if(!dip_status8)
    {
        LED_toggle(LED_1);
        LED_toggle(LED_2);
    }
}
