# FIXED

src/cbuf.obj: ../src/cbuf.c
src/cbuf.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/cbuf.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h

../src/cbuf.c:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h:

