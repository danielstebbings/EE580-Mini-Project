# FIXED

src/framework.obj: ../src/framework.c
src/framework.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h
src/framework.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
src/framework.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
src/framework.obj: C:/ti/c6748/bsl/inc/types.h
src/framework.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/framework.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/framework.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_psc.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_pll.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_gpio.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_i2c.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_mcasp.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_aic3106.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_led.h
src/framework.obj: C:/ti/c6748/bsl/inc/evmc6748_dip.h

../src/framework.c:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/c6748/bsl/inc/types.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/c6748/bsl/inc/evmc6748.h:

C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h:

C:/ti/c6748/bsl/inc/evmc6748_psc.h:

C:/ti/c6748/bsl/inc/evmc6748_pll.h:

C:/ti/c6748/bsl/inc/evmc6748_gpio.h:

C:/ti/c6748/bsl/inc/evmc6748_i2c.h:

C:/ti/c6748/bsl/inc/evmc6748_mcasp.h:

C:/ti/c6748/bsl/inc/evmc6748_aic3106.h:

C:/ti/c6748/bsl/inc/evmc6748_led.h:

C:/ti/c6748/bsl/inc/evmc6748_dip.h:

