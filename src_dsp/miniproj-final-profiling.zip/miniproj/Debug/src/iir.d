# FIXED

src/iir.obj: ../src/iir.c
src/iir.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h
src/iir.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h

../src/iir.c:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h:

