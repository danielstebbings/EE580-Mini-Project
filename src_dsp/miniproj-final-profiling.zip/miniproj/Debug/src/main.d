# FIXED

src/main.obj: ../src/main.c
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdlib.h
src/main.obj: maincfg.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hst.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/pip.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
src/main.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
src/main.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h
src/main.obj: C:/ti/c6748/bsl/inc/types.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_psc.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_pll.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_gpio.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_i2c.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_mcasp.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_aic3106.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_led.h
src/main.obj: C:/ti/c6748/bsl/inc/evmc6748_dip.h
src/main.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/main.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h
src/main.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/state_machine.h
src/main.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/data.h
src/main.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h

../src/main.c:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdlib.h:

maincfg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hst.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/pip.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h:

C:/ti/c6748/bsl/inc/types.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/c6748/bsl/inc/evmc6748.h:

C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h:

C:/ti/c6748/bsl/inc/evmc6748_psc.h:

C:/ti/c6748/bsl/inc/evmc6748_pll.h:

C:/ti/c6748/bsl/inc/evmc6748_gpio.h:

C:/ti/c6748/bsl/inc/evmc6748_i2c.h:

C:/ti/c6748/bsl/inc/evmc6748_mcasp.h:

C:/ti/c6748/bsl/inc/evmc6748_aic3106.h:

C:/ti/c6748/bsl/inc/evmc6748_led.h:

C:/ti/c6748/bsl/inc/evmc6748_dip.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/state_machine.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/data.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h:

