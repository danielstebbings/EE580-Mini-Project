# FIXED

src/mock_audio.obj: ../src/mock_audio.c
src/mock_audio.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/mock_audio.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/mock_audio.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/mock_audio.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/mock_audio.h

../src/mock_audio.c:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/mock_audio.h:

