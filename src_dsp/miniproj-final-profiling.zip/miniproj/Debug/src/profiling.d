# FIXED

src/profiling.obj: ../src/profiling.c
src/profiling.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/profiling.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/time.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/math.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/float.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/access.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/elfnames.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/mathf.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/unaccess.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/mathl.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/unaccess.h
src/profiling.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/string.h

../src/profiling.c:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/profiling.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/time.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/math.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/float.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/access.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/elfnames.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/mathf.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/unaccess.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/mathl.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/unaccess.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/string.h:

