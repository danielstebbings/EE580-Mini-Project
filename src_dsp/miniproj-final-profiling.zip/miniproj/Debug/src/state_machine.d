# FIXED

src/state_machine.obj: ../src/state_machine.c
src/state_machine.obj: maincfg.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hst.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/pip.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h
src/state_machine.obj: C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/types.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_psc.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_pll.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_gpio.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_i2c.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_mcasp.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_aic3106.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_led.h
src/state_machine.obj: C:/ti/c6748/bsl/inc/evmc6748_dip.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/state_machine.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/data.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h
src/state_machine.obj: C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/profiling.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/time.h
src/state_machine.obj: C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/string.h

../src/state_machine.c:

maincfg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/std.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tistdtypes.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/prd.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/fxn.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sts.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hst.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/pip.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/swi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/hwi.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/tsk.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/knl.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/atm.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/que.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/mem.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sem.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/obj.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/sys.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stddef.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_hook.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/_log.h:

C:/ti/bios_5_42_02_10/packages/ti/bios/include/trc.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/framework.h:

C:/ti/c6748/bsl/inc/types.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdio.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/linkage.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/c6748/bsl/inc/evmc6748.h:

C:/ti/c6748/bsl/inc/evmc6748_sysconfig.h:

C:/ti/c6748/bsl/inc/evmc6748_psc.h:

C:/ti/c6748/bsl/inc/evmc6748_pll.h:

C:/ti/c6748/bsl/inc/evmc6748_gpio.h:

C:/ti/c6748/bsl/inc/evmc6748_i2c.h:

C:/ti/c6748/bsl/inc/evmc6748_mcasp.h:

C:/ti/c6748/bsl/inc/evmc6748_aic3106.h:

C:/ti/c6748/bsl/inc/evmc6748_led.h:

C:/ti/c6748/bsl/inc/evmc6748_dip.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/state_machine.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdbool.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/yvals.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdarg.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/_lock.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/cbuf.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/stdint.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/data.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/iir.h:

C:/Users/prebe/Documents/ccs_workspace/miniproj/inc/profiling.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/time.h:

C:/ti/ccs1271/ccs/tools/compiler/c6000_7.3.23/include/string.h:

