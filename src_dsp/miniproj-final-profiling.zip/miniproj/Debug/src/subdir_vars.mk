################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/cbuf.c \
../src/framework.c \
../src/iir.c \
../src/main.c \
../src/mock_audio.c \
../src/profiling.c \
../src/state_machine.c 

C_DEPS += \
./src/cbuf.d \
./src/framework.d \
./src/iir.d \
./src/main.d \
./src/mock_audio.d \
./src/profiling.d \
./src/state_machine.d 

OBJS += \
./src/cbuf.obj \
./src/framework.obj \
./src/iir.obj \
./src/main.obj \
./src/mock_audio.obj \
./src/profiling.obj \
./src/state_machine.obj 

OBJS__QUOTED += \
"src\cbuf.obj" \
"src\framework.obj" \
"src\iir.obj" \
"src\main.obj" \
"src\mock_audio.obj" \
"src\profiling.obj" \
"src\state_machine.obj" 

C_DEPS__QUOTED += \
"src\cbuf.d" \
"src\framework.d" \
"src\iir.d" \
"src\main.d" \
"src\mock_audio.d" \
"src\profiling.d" \
"src\state_machine.d" 

C_SRCS__QUOTED += \
"../src/cbuf.c" \
"../src/framework.c" \
"../src/iir.c" \
"../src/main.c" \
"../src/mock_audio.c" \
"../src/profiling.c" \
"../src/state_machine.c" 


