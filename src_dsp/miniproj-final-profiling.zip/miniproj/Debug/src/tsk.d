# FIXED

src/tsk.obj: ../src/tsk.c

../src/tsk.c:

