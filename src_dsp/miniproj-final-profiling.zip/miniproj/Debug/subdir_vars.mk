################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
S??_SRCS += \
./maincfg.s?? 

TCF_SRCS += \
../main.tcf 

C_SRCS += \
./maincfg_c.c 

S??_DEPS += \
./maincfg.d 

GEN_CMDS += \
./maincfg.cmd 

GEN_FILES += \
./maincfg.cmd \
./maincfg.s?? \
./maincfg_c.c 

C_DEPS += \
./maincfg_c.d 

OBJS += \
./maincfg.obj \
./maincfg_c.obj 

GEN_MISC_FILES += \
./maincfg.h \
./maincfg.h?? \
./main.cdb 

S??_DEPS__QUOTED += \
"maincfg.d" 

OBJS__QUOTED += \
"maincfg.obj" \
"maincfg_c.obj" 

GEN_MISC_FILES__QUOTED += \
"maincfg.h" \
"maincfg.h??" \
"main.cdb" 

C_DEPS__QUOTED += \
"maincfg_c.d" 

GEN_FILES__QUOTED += \
"maincfg.cmd" \
"maincfg.s??" \
"maincfg_c.c" 

S??_SRCS__QUOTED += \
"./maincfg.s??" 

S??_OBJS__QUOTED += \
"maincfg.obj" 

C_SRCS__QUOTED += \
"./maincfg_c.c" 


