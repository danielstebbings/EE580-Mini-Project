
#ifndef CBUF_H
#define CBUF_H

#include <stdint.h>
#include <stdbool.h>

#define SAMPLE_RATE 8000       // hertz
#define RECORDING_TIME_S 4     // seconds
#define BUFFER_SIZE SAMPLE_RATE * RECORDING_TIME_S

typedef struct
{
    int16_t*        buffer;
    int32_t         head;
    int32_t         tail;
    int32_t         count;
    const int32_t   size;
} cbuf_t;

// Initialize the buffer
void init_buffer(cbuf_t *p_cbuf, int16_t* p_buffer);

// Check if the buffer is full
bool is_full(cbuf_t *p_cbuf);

// Check if the buffer is empty
bool is_empty(cbuf_t *p_cbuf);

// Add an element to the buffer
bool enqueue(cbuf_t *p_cbuf, int16_t p_sample);

// Remove an element from the buffer
bool dequeue(cbuf_t *p_cbuf, int16_t *p_sample);

int32_t peek_at(cbuf_t *p_cbuf, int16_t *p_bufout, int32_t p_n_samples, int32_t p_start_idx);
int32_t peek_at_float(cbuf_t *p_cbuf, float *p_bufout, int32_t p_n_samples, int32_t p_start_idx);

#endif // CBUF_H
