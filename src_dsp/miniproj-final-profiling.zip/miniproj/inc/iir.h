/**
 * @file iir.h
 * @brief IIR filter structure definitions and functions.
 */

#ifndef IIR_H_
#define IIR_H_

#include <stdint.h>

//typedef float float;

#define N_NUM 3
#define N_DEN 2

#define SOS_N 5

/// @brief SOS IIR Filter
/// coeffs stored as:
/// 
/// b_0, b_1, ..., b_(lnum-1), a1, a2, ..., a(lden-1) 
typedef struct iir_filter_t {
    const int nstages;
    const int lnum;
    const int lden;
    const float  g;
    const float* coeffs;
    float tdl[3][SOS_N+1];
    } iir_filter_t;


void sos_filter(
    float input[], uint32_t input_length,
    float output[],
    iir_filter_t* filt
);

void opt_sos_filter(
    float input[], uint32_t input_length,
    float output[],
    iir_filter_t* filt
);

void sos_filter_int(
    int16_t input[], uint32_t input_length,
    int16_t output[],
    iir_filter_t* filt
);
void sos_filter_fast16(
    int16_t input[], uint32_t input_length,
    int16_t output[],
    iir_filter_t* filt
);

#endif
