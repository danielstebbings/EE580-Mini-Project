
#ifndef PROFILING_H
#define PROFILING_H

#include <stdint.h>
#include <time.h>

typedef float float32_t;

// profiling definitions
#undef CLOCKS_PER_SEC
#define CLOCKS_PER_SEC (300000000)
extern cregister volatile unsigned int TSCL;
extern cregister volatile unsigned int TSCH;


/**
 * @brief Returns current clock cycle.
 *
 * @return clock_t
 *
 */
clock_t clock(void);

#endif // PROFILING_H
