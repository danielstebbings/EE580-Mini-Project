/*
 * state_machine.h
 *
 *  Created on: 30. mar. 2026
 *      Author: prebe
 */

#ifndef STATE_MACHINE_H_
#define STATE_MACHINE_H_

#include <stdbool.h>
#include "cbuf.h"
#include "data.h"
#include "iir.h"

#define AUDIOBUF_LEN 500
#define SAMPLE_RATE 8000       // hertz
#define RECORDING_TIME_S 4     // seconds
#define BUFFER_SIZE SAMPLE_RATE * RECORDING_TIME_S

typedef float float32_t;

typedef enum {
    // S2:1 = OFF
    // Behavior: Standby, no audio output, both LEDs OFF.
    SYS_STATE_STANDBY,

    // S2:1 = ON, S2:2 = OFF
    // Behavior: Record 4s to circular buffer at 8kHz, loopback LINE IN to LINE OUT.
    // Both LEDs toggle at 20Hz.
    SYS_STATE_RECORD,

    // S2:1 = ON, S2:2 = ON
    // Behavior: Playback 4s buffer circularly. LEDs toggles at 2Hz.
    // Audio output depends on S2:6-8.
    SYS_STATE_PLAYBACK

} system_state_t;


extern volatile system_state_t g_sys_state;
extern volatile bool g_audio_buf_ready;

extern int16_t g_data[BUFFER_SIZE];
extern int16_t g_audio_out[BUFFER_SIZE];

extern cbuf_t cbuf;


#endif /* STATE_MACHINE_H_ */
