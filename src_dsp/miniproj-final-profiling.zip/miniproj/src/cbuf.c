/**
 * @file cbuf.c
 * @brief Circular buffer implementation
 */
#include "cbuf.h"
#include <stdbool.h>


// Initialize buffer
void init_buffer(cbuf_t *p_cbuf, int16_t* p_buffer)
{
    p_cbuf->buffer = p_buffer;
    p_cbuf->count = 0;
    p_cbuf->head = 0;
    p_cbuf->tail = 0;
    // p_cbuf->size set when initializing cbuf_t
}

bool is_full(cbuf_t *p_cbuf)
{
    return p_cbuf->count == p_cbuf->size;
}

bool is_empty(cbuf_t *p_cbuf)
{
    return p_cbuf->count == 0;
}

bool enqueue(cbuf_t *p_cbuf, int16_t p_sample)
{
    // null ptr return
    if (!p_cbuf) return false;

    // add sample at buffer tail
    p_cbuf->buffer[p_cbuf->tail] = p_sample;
    // advance tail with wrap-around
    p_cbuf->tail = (p_cbuf->tail + 1) % p_cbuf->size;

    if (p_cbuf->count == p_cbuf->size)
    {
        // buffer is full, oldest sample has been overwritten
        p_cbuf->head = (p_cbuf->head + 1) % p_cbuf->size;

    } else {
        // increment count.
        p_cbuf->count++;
    }
    return true;
}

bool dequeue(cbuf_t *p_cbuf, int16_t *p_sample)
{
    if (is_empty(p_cbuf))
    {
        return false;
    }

    // Read data from head
    *p_sample = p_cbuf->buffer[p_cbuf->head];

    // advance head with wrap-around
    p_cbuf->head = (p_cbuf->head + 1) % p_cbuf->size;

    // decrement count
    p_cbuf->count--;

    return true;
}

int32_t peek_at(cbuf_t *p_cbuf, int16_t *p_bufout, int32_t p_n_samples, int32_t p_start_idx)
{
    if (!p_cbuf || !p_bufout || p_n_samples <= 0)
    {
        return 0;
    }

    if (p_start_idx < 0 || p_start_idx >= p_cbuf->size)
    {
        return 0;
    }

    // how many valid samples exist after p_start_idx
    int32_t offset = p_start_idx - p_cbuf->head;
    if (offset < 0)
    {
        offset += p_cbuf->size; // handle wrap-around
    }

    int32_t available_samples;
    if (p_cbuf->count == p_cbuf->size)
    {
        available_samples = p_cbuf->size;
    }
    else
    {
        available_samples = p_cbuf->count - offset;
    }

    // if start_idx is outside the valid written range, nothing to copy
    if (available_samples <= 0)
    {
        return 0;
    }

    // bound the copy operation to available number of samples
    int32_t samples_to_copy = (p_n_samples > available_samples) ? available_samples : p_n_samples;
    int32_t samples_to_end = p_cbuf->size - p_start_idx;

    if (samples_to_copy <= samples_to_end)
    {
        // data is contiguous (no wrap-around)
        memcpy(p_bufout, &p_cbuf->buffer[p_start_idx], samples_to_copy * sizeof(int16_t));
    }
    else
    {
        // data wraps around (need two copies)
        memcpy(p_bufout, &p_cbuf->buffer[p_start_idx], samples_to_end * sizeof(int16_t));

        int32_t remaining_samples = samples_to_copy - samples_to_end;
        memcpy(p_bufout + samples_to_end, p_cbuf->buffer, remaining_samples * sizeof(int16_t));
    }

    // return number of elements copied into p_bufout
    return samples_to_copy;
}

typedef float float32_t;

int32_t peek_at_float(cbuf_t *p_cbuf, float32_t *p_bufout, int32_t p_n_samples, int32_t p_start_idx)
{
    if (!p_cbuf || !p_bufout || p_n_samples <= 0)
    {
        return 0;
    }

    if (p_start_idx < 0 || p_start_idx >= p_cbuf->size)
    {
        return 0;
    }

    // how many valid samples exist after p_start_idx
    int32_t offset = p_start_idx - p_cbuf->head;
    if (offset < 0)
    {
        offset += p_cbuf->size; // handle wrap-around
    }

    int32_t available_samples;
    if (p_cbuf->count == p_cbuf->size)
    {
        available_samples = p_cbuf->size;
    }
    else
    {
        available_samples = p_cbuf->count - offset;
    }

    if (available_samples <= 0)
    {
        return 0;
    }

    int32_t samples_to_copy = (p_n_samples > available_samples) ? available_samples : p_n_samples;
    int32_t samples_to_end = p_cbuf->size - p_start_idx;

    if (samples_to_copy <= samples_to_end)
    {
        int32_t i;
        #pragma MUST_ITERATE(1, BUFFER_SIZE, )
        for (i = 0; i < samples_to_copy; i++)
        {
            p_bufout[i] = (float32_t)p_cbuf->buffer[p_start_idx + i];
        }
    }
    else
    {
        int32_t i;
        #pragma MUST_ITERATE(1, BUFFER_SIZE, )
        for (i = 0; i < samples_to_end; i++)
        {
            p_bufout[i] = (float32_t)p_cbuf->buffer[p_start_idx + i];
        }

        int32_t remaining_samples = samples_to_copy - samples_to_end;
        #pragma MUST_ITERATE(1, BUFFER_SIZE, )
        for (i = 0; i < remaining_samples; i++)
        {
            p_bufout[samples_to_end + i] = (float32_t)p_cbuf->buffer[i];
        }
    }

    return samples_to_copy;
}
