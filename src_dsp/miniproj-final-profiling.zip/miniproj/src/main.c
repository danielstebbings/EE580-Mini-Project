/**
 * main.c
 */
//---------------------------------------------------------
// INCLUDES
//---------------------------------------------------------
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "maincfg.h" //BIOS include file
#include "framework.h"

#include "cbuf.h"
#include "state_machine.h"

//---------------------------------------------------------
// GLOBAL DECLARATIONS
//---------------------------------------------------------

// current system state
volatile system_state_t g_sys_state = SYS_STATE_STANDBY;
// high when active filter selection has been applied
volatile bool g_audio_buf_ready = 0;

// audio input, circular buffer
#pragma DATA_ALIGN(g_data, 8);
int16_t g_data[BUFFER_SIZE] = { 0 };
// audio output, linear buffer
#pragma DATA_ALIGN(g_audio_out, 8);
int16_t g_audio_out[BUFFER_SIZE] = { 0 };

// circular buffer struct
cbuf_t cbuf =
{
    g_data,
    0,
    0,
    0,
    BUFFER_SIZE,
};


//---------------------------------------------------------
// STATIC DECLARATIONS
//---------------------------------------------------------

// index of audio output sample
static volatile int32_t g_audio_buf_idx = 0;


//---------------------------------------------------------
// STATIC FUNCTIONS
//---------------------------------------------------------


//---------------------------------------------------------
// MAIN
//---------------------------------------------------------
void main(void)
{
    initAll();
    LOG_printf(&trace, "Start IIR Filter Demo");

    return; // return to BIOS scheduler
}
//---------------------------------------------------------
// HWI ISR
//---------------------------------------------------------
void audioHWI(void)
{
    int16_t s16;
    s16 = read_audio_sample(); // can't be placed in switch-case

    // only play through right channel
    if (MCASP->RSLOT)
    {
        // THIS IS THE LEFT CHANNEL!!!
        write_audio_sample(0);
        return;
    }

    switch(g_sys_state)
    {
    // no output
    case SYS_STATE_STANDBY:
        write_audio_sample(0);
        return;

    // buffer and pass-through audio
    case SYS_STATE_RECORD:
        enqueue(&cbuf, s16);       // add sample to buffer
        write_audio_sample(s16);   // pass through audio
        return;

    // output filtered audio
    case SYS_STATE_PLAYBACK:
        if(g_audio_buf_idx >= BUFFER_SIZE) // wrap-around buffer read
        {
            g_audio_buf_idx = 0;
        }
        write_audio_sample(g_audio_out[g_audio_buf_idx++]);
        return;

    // safety case
    default:
        write_audio_sample(0);
        return;
    }

}
