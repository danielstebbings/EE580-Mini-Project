/*
 * profiling.c
 *
 */

#include "profiling.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

clock_t clock(void)
{
    unsigned int low  = TSCL;
    unsigned int high = TSCH;
    if(high) return (clock_t)-1;
    return low;
}
