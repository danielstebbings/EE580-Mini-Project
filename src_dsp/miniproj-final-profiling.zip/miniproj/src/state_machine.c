/*
 * state_machine.c
 *
 *  Created on: 31. mar. 2026
 *      Author: prebe
 */
//---------------------------------------------------------
// INCLUDES
//---------------------------------------------------------
#include "maincfg.h" //BIOS include file
#include "framework.h"
#include "state_machine.h"
#include "profiling.h"
#include "data.h"
#include "iir.h"
#include "cbuf.h"
#include <string.h>

#define MAX_ACTIVE_FILTERS 3

//---------------------------------------------------------
// GLOBAL DECLARATIONS
//---------------------------------------------------------


//---------------------------------------------------------
// STATIC DECLARATIONS
//---------------------------------------------------------

static iir_filter_t lp_filt =
{
      lp_N_SOS,
      lp_N_NUM,
      lp_N_DEN,
      lp_G_SOS,
      lp_coeffs,
};


static iir_filter_t hp_filt =
{
      hp_N_SOS,
      lp_N_NUM,
      lp_N_DEN,
      hp_G_SOS,
      hp_coeffs,
};


static iir_filter_t bp_filt =
{
      bp_N_SOS,
      lp_N_NUM,
      lp_N_DEN,
      bp_G_SOS,
      bp_coeffs,
};

#pragma DATA_ALIGN(g_audio_in, 8);
static float32_t g_audio_in[AUDIOBUF_LEN] = {0};
#pragma DATA_ALIGN(g_audio_buf, 8);
static float32_t g_audio_buf[AUDIOBUF_LEN] = {0};

static iir_filter_t *g_active_filters[MAX_ACTIVE_FILTERS] = {0};
static volatile int32_t g_current_read_idx = 0;


//---------------------------------------------------------
// STATIC FUNCTIONS
//---------------------------------------------------------

static void apply_parallel_filters(iir_filter_t **p_active_filters, uint8_t p_num_filters, cbuf_t *p_cbuf, float32_t *p_audio_in, float32_t *p_audio_temp, int16_t *p_audio_out);
static void apply_parallel_filters_opt(iir_filter_t **p_active_filters, uint8_t p_num_filters, cbuf_t *p_cbuf, float32_t *p_audio_in, float32_t *p_audio_temp, int16_t *p_audio_out);

static void playback_filter_selection(void);
static void profile_filter_permutations(void);


//---------------------------------------------------------
// SWI ISR
//---------------------------------------------------------

// toggles at 20 Hz
// handles LED output state
void dipPRD0(void)
{
    if( g_sys_state == SYS_STATE_RECORD)
    {
        LED_toggle(LED_1);
        LED_toggle(LED_2);
    }
}

// toggles at 6 Hz
// handles LED output state
void dipPRD1(void)
{
    if( g_sys_state == SYS_STATE_PLAYBACK)
    {
        LED_toggle(LED_1);
        LED_toggle(LED_2);
    }
}

// executes every 50 ms
// updates system state and audio output buffer
void dipState(void)
{
    uint8_t l_dip_status1, l_dip_status2;
    DIP_get(DIP_1, &l_dip_status1);
    DIP_get(DIP_2, &l_dip_status2);

    // SYS_STATE_STANDBY
    if(!l_dip_status1)
    {
        if( g_sys_state != SYS_STATE_STANDBY)
        {
            LED_turnOff(LED_1);
            LED_turnOff(LED_2);
        }
        g_sys_state = SYS_STATE_STANDBY;
    }
    // SYS_STATE_RECORD
    else if(l_dip_status1 && !l_dip_status2)
    {
        if( g_sys_state == SYS_STATE_PLAYBACK || g_sys_state == SYS_STATE_STANDBY)
        {
            // reset circular buffer
            g_audio_buf_ready = 0;
            init_buffer(&cbuf, g_data);
        }
        g_sys_state = SYS_STATE_RECORD;
    }
    // SYS_STATE_PLAYBACK
    else if(l_dip_status1 && l_dip_status2)
    {
        // wait until buffer has been filled
        if(!is_full(&cbuf))
        {
            g_sys_state = SYS_STATE_RECORD;
            return;
        }
        playback_filter_selection();
        g_sys_state = SYS_STATE_PLAYBACK;
    }
    else
    {
        g_sys_state = SYS_STATE_STANDBY;
    }
    return;
}


static void playback_filter_selection(void)
{
    // CPU cycle profiling
    clock_t start, stop, overhead;
    start = clock();
    stop = clock();
    overhead = stop - start;

    // get filter selection status
    uint8_t l_dip_status6, l_dip_status7, l_dip_status8;
    DIP_get(DIP_6, &l_dip_status6);
    DIP_get(DIP_7, &l_dip_status7);
    DIP_get(DIP_8, &l_dip_status8);

    // array of ptrs to active filters
    iir_filter_t* l_active_filters[MAX_ACTIVE_FILTERS] = { 0 };
    uint8_t l_num_filters = 0;

    // select relevant filters
    if(l_dip_status6)
    {
        l_active_filters[l_num_filters++] = &lp_filt;
    }
    if(l_dip_status7)
    {
        l_active_filters[l_num_filters++] = &bp_filt;
    }
    if(l_dip_status8)
    {
        l_active_filters[l_num_filters++] = &hp_filt;
    }

    // check if active filters have changed
    if(memcmp(l_active_filters, g_active_filters, sizeof(l_active_filters)) == 0 && g_audio_buf_ready == 1)
    {
        return; // active filters haven't changed, output buffered audio --> exit early
    }
    memcpy(g_active_filters, l_active_filters, MAX_ACTIVE_FILTERS*sizeof(iir_filter_t *));

    // produce new audio output, reset flag
    g_audio_buf_ready = 0;

    // perform parallel IIR filtering
    apply_parallel_filters_opt(l_active_filters, l_num_filters, &cbuf, g_audio_in, g_audio_buf, g_audio_out);

//    profile_filter_permutations();

    // audio output ready
    g_audio_buf_ready = 1;
    return;
}

static void apply_parallel_filters(iir_filter_t **p_active_filters, uint8_t p_num_filters, cbuf_t *p_cbuf, float32_t *p_audio_in, float32_t *p_audio_temp, int16_t *p_audio_out)
{
    int bufit;
    int32_t l_total_samples_read = 0;
    int32_t l_samples_read = 0;
    int32_t i, filter_n;

    // reset audio output buffer
    memset(p_audio_out, 0, BUFFER_SIZE* sizeof(int16_t));

    // return if no active filters
    if(p_num_filters == 0)
    {
        return;
    }

    // initialise tdl of active filters
    for (filter_n = 0; filter_n < p_num_filters; filter_n++)
    {
        memset(p_active_filters[filter_n]->tdl, 0, sizeof(p_active_filters[filter_n]->tdl));
    }

    // filter audio buffer in chunks
    for (bufit = 0; bufit < BUFFER_SIZE / AUDIOBUF_LEN; bufit++)
    {
        l_samples_read = peek_at_float(p_cbuf, p_audio_in, AUDIOBUF_LEN, g_current_read_idx);
        g_current_read_idx = (g_current_read_idx + l_samples_read) % p_cbuf->size;

        float32_t l_audio_sum[AUDIOBUF_LEN] = {0};

        // apply all active filters to this chunk
        for (filter_n = 0; filter_n < p_num_filters; filter_n++)
        {
            // apply filter
            sos_filter(p_audio_in, l_samples_read, p_audio_temp, p_active_filters[filter_n]);
            for (i = 0; i < l_samples_read; i++)
            {
                l_audio_sum[i] += p_audio_temp[i];
            }
        }
        // sum into final audio output
        for (i = 0; i < l_samples_read; i++)
        {
            float32_t l_sample_f = l_audio_sum[i];

            // clip final sum to prevent integer overflow
            if (l_sample_f > 32767.0f) {
                l_sample_f = 32767.0f;
            } else if (l_sample_f < -32768.0f) {
                l_sample_f = -32768.0f;
            }

            p_audio_out[l_total_samples_read + i] += (int16_t)l_sample_f;
        }
        l_total_samples_read += l_samples_read;
    }

}

static void apply_parallel_filters_opt(iir_filter_t **restrict p_active_filters, uint8_t p_num_filters, cbuf_t *restrict p_cbuf, float32_t *restrict p_audio_in, float32_t *restrict p_audio_temp, int16_t *restrict p_audio_out)
{
    _nassert((int)p_audio_temp % 8 == 0);
    _nassert((int)p_audio_out % 8 == 0);
    int bufit;
    int32_t l_total_samples_read = 0;
    int32_t l_samples_read = 0;
    int32_t i, filter_n;

    // reset audio output buffer
    memset(p_audio_out, 0, BUFFER_SIZE* sizeof(int16_t));

    // return if no active filters
    if(p_num_filters == 0)
    {
        return;
    }

    // initialise tdl of active filters
    #pragma MUST_ITERATE (1, MAX_ACTIVE_FILTERS, );
    for (filter_n = 0; filter_n < p_num_filters; filter_n++)
    {
        memset(p_active_filters[filter_n]->tdl, 0, sizeof(p_active_filters[filter_n]->tdl));
    }

    // filter audio buffer in chunks
    for (bufit = 0; bufit < BUFFER_SIZE / AUDIOBUF_LEN; bufit++)
    {
        l_samples_read = peek_at_float(p_cbuf, p_audio_in, AUDIOBUF_LEN, g_current_read_idx);
        g_current_read_idx = (g_current_read_idx + l_samples_read) % p_cbuf->size;

        float32_t l_audio_sum[AUDIOBUF_LEN] = {0};

        // apply all active filters to this chunk
        for (filter_n = 0; filter_n < p_num_filters; filter_n++)
        {
            // apply filter
            opt_sos_filter(p_audio_in, l_samples_read, p_audio_temp, p_active_filters[filter_n]);

            #pragma UNROLL(4)
            #pragma MUST_ITERATE (AUDIOBUF_LEN, AUDIOBUF_LEN,4);
            for (i = 0; i < l_samples_read; i++)
            {
                l_audio_sum[i] += p_audio_temp[i];
            }
        }
        // sum into final audio output
        #pragma UNROLL(2)
        #pragma MUST_ITERATE(2, AUDIOBUF_LEN / 2, 2)
        for (i = 0; i < l_samples_read; i += 2)
        {
            float32_t f1 = l_audio_sum[i];
            float32_t f2 = l_audio_sum[i+1];

            // cast from float to int32_t
            int32_t i1 = _spint(f1);
            int32_t i2 = _spint(f2);

            // convert to int16_t, saturate, and pack
            int32_t packed_new_int_16 = _spack2(i2, i1);

            // get existing samples
            int32_t packed_existing_int_16 = _amem4(&p_audio_out[l_total_samples_read + i]);

            // sum samples with saturation
            int32_t packed_sum_16 = _sadd2(packed_existing_int_16, packed_new_int_16);

            // store
            _amem4(&p_audio_out[l_total_samples_read + i]) = packed_sum_16;
        }
        l_total_samples_read += l_samples_read;
    }

}


static void profile_filter_permutations(void)
{
    clock_t start, stop, overhead;
    start = clock();
    stop = clock();
    overhead = stop - start;
    uint32_t cycles_nonopt, cycles_opt;

    LOG_printf(&trace, "--- Start Filter Profiling ---\r\n");
    uint8_t permutation;
    // Loop from 0 to 7 (Binary 000 to 111) to cover all permutations
    for (permutation = 0; permutation < 8; permutation++)
    {
        // simulate dip switch states
        uint8_t sim_dip6 = (permutation & 0x01) ? 1 : 0; // Bit 0 (Low-Pass)
        uint8_t sim_dip7 = (permutation & 0x02) ? 1 : 0; // Bit 1 (Band-Pass)
        uint8_t sim_dip8 = (permutation & 0x04) ? 1 : 0; // Bit 2 (High-Pass)

        // active filter ptrs
        iir_filter_t* l_active_filters[MAX_ACTIVE_FILTERS] = { 0 };
        uint8_t l_num_filters = 0;

        // select filters based on simulated dip
        if (sim_dip6) l_active_filters[l_num_filters++] = &lp_filt;
        if (sim_dip7) l_active_filters[l_num_filters++] = &bp_filt;
        if (sim_dip8) l_active_filters[l_num_filters++] = &hp_filt;

        // profile non-optimized function
        start = clock();
        apply_parallel_filters(l_active_filters, l_num_filters, &cbuf, g_audio_in, g_audio_buf, g_audio_out);
        stop = clock();
        cycles_nonopt = stop - start - overhead;

        // profile optimized function
        start = clock();
        apply_parallel_filters_opt(l_active_filters, l_num_filters, &cbuf, g_audio_in, g_audio_buf, g_audio_out);
        stop = clock();
        cycles_opt = stop - start - overhead;

        // LOG results
        LOG_printf(&trace, "Permutation -> LP:%d BP:%d", sim_dip6, sim_dip7);
        LOG_printf(&trace, " HP:%d\r\n", sim_dip8);

        LOG_printf(&trace, "  Non-Opt Cycles: %u\r\n", cycles_nonopt);
        LOG_printf(&trace, "  Opt Cycles:     %u\r\n", cycles_opt);
    }

    LOG_printf(&trace, "--- Profiling Complete ---\r\n");
}
